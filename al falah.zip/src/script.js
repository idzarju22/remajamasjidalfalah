function toggleMenu() {
    document.getElementById('menu').classList.toggle('hidden');
  }